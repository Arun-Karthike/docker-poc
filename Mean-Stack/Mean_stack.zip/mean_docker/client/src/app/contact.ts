export class Contact {
    _id? : string;
    firstname : string;
    lastname : string;
    phone : string;
}