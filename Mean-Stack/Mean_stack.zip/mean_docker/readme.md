`For Express server`
1. Run command `npm install` in root, it will install all the server dependencies
2. Run `node app.js`

`For client side`
1. Got to `client` folder
1. Run command `npm install`, it will install all the angular dependencies
2. Run `ng serve`

Versions 
 nodejs = ^10
 angular = 7